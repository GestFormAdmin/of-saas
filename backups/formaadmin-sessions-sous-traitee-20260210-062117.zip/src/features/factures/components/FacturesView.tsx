export { default } from './FacturesBase'
