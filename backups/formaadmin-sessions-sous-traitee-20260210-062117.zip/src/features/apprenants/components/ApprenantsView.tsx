export { default } from './ApprenantsBase'
