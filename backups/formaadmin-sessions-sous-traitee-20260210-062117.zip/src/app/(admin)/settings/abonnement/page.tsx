export default function BillingPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Abonnement</h1>
          <p className="text-sm text-gray-500">Gestion du plan et de la facturation</p>
        </div>

        <button className="btn btn-primary">
          Mettre à niveau
        </button>
      </div>

      <div className="card space-y-4">
        <h2 className="text-lg font-medium">Plan actuel</h2>

        <div className="rounded-lg border p-4 flex items-center justify-between">
          <div>
            <p className="font-semibold">Gratuit</p>
            <p className="text-sm text-gray-500">Configuration ultérieure</p>
          </div>

          <span className="inline-flex items-center rounded-full bg-gray-100 px-3 py-1 text-sm font-medium text-gray-700">
            Actif
          </span>
        </div>

        <div className="rounded-lg border p-4 text-sm text-gray-400">
          Stripe à brancher plus tard
        </div>
      </div>
    </div>
  )
}
