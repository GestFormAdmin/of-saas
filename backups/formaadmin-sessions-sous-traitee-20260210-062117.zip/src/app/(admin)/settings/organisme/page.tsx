"use client";

import * as React from "react";
import { supabase } from "@/lib/supabase/browser";
import ProfileLogoUploader from "@/features/profile/ProfileLogoUploader";

type Org = {
  id: string;
  name: string | null;
  org_type: "business" | "personal" | string | null;
  logo_url?: string | null;
};

export default function OrganismePage() {
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [message, setMessage] = React.useState<string | null>(null);

  const [userId, setUserId] = React.useState<string | null>(null);
  const [email, setEmail] = React.useState("");
  const [newEmail, setNewEmail] = React.useState("");

  const [currentOrg, setCurrentOrg] = React.useState<Org | null>(null);
  const [role, setRole] = React.useState<"owner" | "admin" | "member">("member");

  const [orgName, setOrgName] = React.useState("");
  const [firstName, setFirstName] = React.useState("");
  const [lastName, setLastName] = React.useState("");
  const [userLogoUrl, setUserLogoUrl] = React.useState<string | null>(null);

  const [inviteOpen, setInviteOpen] = React.useState(false);
  const [inviteEmail, setInviteEmail] = React.useState("");
  const [inviteRole, setInviteRole] = React.useState<"member" | "admin">("member");
  const [inviteSending, setInviteSending] = React.useState(false);

  const [newPassword, setNewPassword] = React.useState("");
  const [newPassword2, setNewPassword2] = React.useState("");

  const [deletePassword, setDeletePassword] = React.useState("");
  const [deleteConfirmText, setDeleteConfirmText] = React.useState("");

  const load = async () => {
    setLoading(true);
    setMessage(null);

    const { data: userData, error: userErr } = await supabase.auth.getUser();
    if (userErr) {
      setMessage(userErr.message);
      setLoading(false);
      return;
    }

    const user = userData.user;
    if (!user) {
      setMessage("Non connecté");
      setLoading(false);
      return;
    }

    setUserId(user.id);
    setEmail(user.email ?? "");
    setNewEmail(user.email ?? "");

    const { data: curOrgId, error: curOrgErr } = await supabase.rpc("current_org_id");
    if (curOrgErr || !curOrgId) {
      setCurrentOrg(null);
      setLoading(false);
      return;
    }

    const { data: org, error: orgErr } = await supabase
      .from("organizations")
      .select("id,name,org_type,logo_url")
      .eq("id", curOrgId)
      .maybeSingle();

    if (orgErr || !org) {
      setMessage(orgErr?.message || "Org introuvable");
      setCurrentOrg(null);
      setLoading(false);
      return;
    }

    setCurrentOrg(org as Org);
    setOrgName(org.name ?? "");

    const { data: memData, error: memErr } = await supabase.rpc("get_my_memberships");
    if (!memErr && Array.isArray(memData)) {
      const m = (memData as any[]).find((x: any) => x.org_id === curOrgId);
      setRole((m?.role ?? "member") as any);
    }

    const { data: profile, error: profErr } = await supabase
      .from("profiles")
      .select("first_name,last_name,logo_url")
      .eq("id", user.id)
      .maybeSingle();

    if (profErr) setMessage(profErr.message);

    setFirstName(profile?.first_name ?? "");
    setLastName(profile?.last_name ?? "");
    setUserLogoUrl(profile?.logo_url ?? null);

    setLoading(false);
  };

  React.useEffect(() => {
    let alive = true;
    (async () => {
      await load();
    })();

    const onOrgChanged = () => {
      if (!alive) return;
      void load();
    };

    window.addEventListener("fa:org_changed", onOrgChanged);
    return () => {
      alive = false;
      window.removeEventListener("fa:org_changed", onOrgChanged);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

const isInvitedOnly = role !== "admin" && role !== "owner";
  const canEditOrg = role === "owner" || role === "admin";

  const createMyOF = async () => {
    setSaving(true);
    setMessage(null);

    const name = window.prompt("Nom de l'organisme (OF) ?");
    if (!name) {
      setSaving(false);
      return;
    }

    const { data: newOrgId, error } = await supabase.rpc("create_business_org", { p_name: name });

    if (error || !newOrgId) {
      setMessage(error?.message || "Création impossible");
      setSaving(false);
      return;
    }

    await supabase.rpc("set_current_org", { p_org_id: newOrgId });
    window.dispatchEvent(new Event("fa:org_changed"));

    setSaving(false);
    setMessage("Organisme créé ✅");
  };

  const save = async () => {
    if (!currentOrg || !userId) return;
    setSaving(true);
    setMessage(null);

    if (canEditOrg) {
  const desired = orgName.trim();
  if (!desired) {
    setMessage("Nom d’organisme requis.");
    setSaving(false);
    return;
  }

  const { error: orgErr } = await supabase.rpc("update_current_org_name", { p_name: desired });
  if (orgErr) {
    setMessage(orgErr.message);
    setSaving(false);
    return;
  }
}


    const { error: profErr } = await supabase
      .from("profiles")
      .update({
        first_name: firstName.trim() || null,
        last_name: lastName.trim() || null,
      })
      .eq("id", userId);

    if (profErr) {
      setMessage(profErr.message);
      setSaving(false);
      return;
    }

    setSaving(false);
    setMessage("Enregistré ✅");
    window.dispatchEvent(new Event("fa:org_changed"));
    await load();
  };

  const sendInvite = async () => {
    if (!currentOrg?.id) return;
    setInviteSending(true);
    setMessage(null);

    const cleaned = inviteEmail.trim().toLowerCase().replace("#", "@");
    if (!cleaned) {
      setMessage("Email requis");
      setInviteSending(false);
      return;
    }

    const { error } = await supabase.rpc("create_invite", {
      p_org_id: currentOrg.id,
      p_email: cleaned,
      p_role: inviteRole,
    });

    if (error) {
      setMessage(error.message);
      setInviteSending(false);
      return;
    }

    setInviteOpen(false);
    setInviteEmail("");
    setInviteRole("member");
    setInviteSending(false);
    setMessage("Invitation créée ✅");
  };

  const changePassword = async () => {
    setMessage(null);
    if (!newPassword || newPassword !== newPassword2) {
      setMessage("Mot de passe: erreur de confirmation.");
      return;
    }
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) {
      setMessage(error.message);
      return;
    }
    setNewPassword("");
    setNewPassword2("");
    setMessage("Mot de passe mis à jour ✅");
  };

  const changeEmail = async () => {
    setMessage(null);
    const e = newEmail.trim().toLowerCase();
    if (!e) {
      setMessage("Email requis");
      return;
    }
    const { error } = await supabase.auth.updateUser({ email: e });
    if (error) {
      setMessage(error.message);
      return;
    }
    setMessage("Email mis à jour ✅ (confirmation requise)");
  };

  const deleteAccount = async () => {
    setMessage(null);
    if (deleteConfirmText !== "SUPPRIMER") {
      setMessage('Tape "SUPPRIMER" pour confirmer.');
      return;
    }
    if (!email) {
      setMessage("Email introuvable.");
      return;
    }
    if (!deletePassword) {
      setMessage("Mot de passe requis.");
      return;
    }

    const { error: reauthErr } = await supabase.auth.signInWithPassword({
      email,
      password: deletePassword,
    });
    if (reauthErr) {
      setMessage("Mot de passe incorrect.");
      return;
    }

    const { error } = await supabase.rpc("delete_my_account");
    if (error) {
      setMessage(error.message);
      return;
    }

    await supabase.auth.signOut();
    window.location.href = "/";
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Mon compte</h1>
          <p className="text-sm text-gray-500">Profil utilisateur et organisme</p>
        </div>

        <div className="flex gap-2">
{canEditOrg && !isInvitedOnly && (
            <button className="btn btn-secondary" onClick={() => setInviteOpen(true)} disabled={loading} type="button">
              + Inviter
            </button>
          )}

          {!isInvitedOnly && currentOrg && (
            <button className="btn btn-primary" onClick={() => void save()} disabled={loading || saving} type="button">
              {saving ? "Enregistrement..." : "Enregistrer"}
            </button>
          )}
        </div>
      </div>

      {message && (
        <div className="rounded-xl border bg-gray-50 p-4 text-sm font-medium text-gray-700">{message}</div>
      )}

      {isInvitedOnly ? (
        <div className="card space-y-4">
          <h2 className="text-lg font-medium">Vous êtes utilisateur invité</h2>
          <p className="text-sm text-gray-500">Vous ne pouvez pas gérer cet OF. Créez votre propre OF pour continuer.</p>
          <button className="btn btn-primary" onClick={() => void createMyOF()} disabled={saving || loading} type="button">
            {saving ? "Création..." : "Créer mon OF"}
          </button>
        </div>
      ) : (
        <>
          <div className="card space-y-4">
            <h2 className="text-lg font-medium">Mon profil</h2>

            <ProfileLogoUploader
              initialUrl={userLogoUrl}
              onSaved={(url) => {
                setUserLogoUrl(url);
                window.dispatchEvent(new Event("fa:org_changed"));
              }}
            />

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <input className="input" placeholder="Prénom" value={firstName} onChange={(e) => setFirstName(e.target.value)} disabled={loading} />
              <input className="input" placeholder="Nom" value={lastName} onChange={(e) => setLastName(e.target.value)} disabled={loading} />
            </div>

            <input className="input" value={email} disabled />
          </div>

          {currentOrg && (
            <div className="card space-y-4">
              <h2 className="text-lg font-medium">Organisme</h2>

              <input
                className="input"
                placeholder="Nom de l’organisme"
                value={orgName}
                onChange={(e) => setOrgName(e.target.value)}
disabled={loading || !canEditOrg}
              />

              <div className="text-sm text-gray-500">
                Type : <b>{currentOrg.org_type}</b> — Rôle : <b>{role}</b>
              </div>

             
            </div>
          )}

          <div className="card space-y-4">
            <h2 className="text-lg font-medium">Sécurité du compte</h2>

            <div className="space-y-2">
              <div className="text-sm font-medium">Changer mot de passe</div>
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                <input className="input" type="password" placeholder="Nouveau mot de passe" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
                <input className="input" type="password" placeholder="Confirmer" value={newPassword2} onChange={(e) => setNewPassword2(e.target.value)} />
              </div>
              <button className="btn btn-secondary" onClick={() => void changePassword()} type="button">
                Mettre à jour le mot de passe
              </button>
            </div>

            <div className="h-px bg-gray-100" />

            <div className="space-y-2">
              <div className="text-sm font-medium">Changer email</div>
              <input className="input" placeholder="nouveau@email.com" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} />
              <button className="btn btn-secondary" onClick={() => void changeEmail()} type="button">
                Mettre à jour l’email
              </button>
            </div>
          </div>

          <div className="card space-y-4 border-red-200">
            <h2 className="text-lg font-medium text-red-700">Supprimer mon compte</h2>
            <input className="input" placeholder='Tape "SUPPRIMER"' value={deleteConfirmText} onChange={(e) => setDeleteConfirmText(e.target.value)} />
            <input className="input" type="password" placeholder="Mot de passe" value={deletePassword} onChange={(e) => setDeletePassword(e.target.value)} />
            <button className="btn btn-danger" onClick={() => void deleteAccount()} type="button">
              Supprimer définitivement
            </button>
          </div>
        </>
      )}

      {inviteOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4">
          <div className="w-full max-w-md space-y-4 rounded-xl border bg-white p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Inviter un utilisateur</h3>
              <button className="btn btn-secondary" onClick={() => setInviteOpen(false)} type="button">
                Fermer
              </button>
            </div>

            <input className="input" value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} placeholder="email@exemple.com" />

            <select className="input" value={inviteRole} onChange={(e) => setInviteRole(e.target.value as any)}>
              <option value="member">Utilisateur</option>
              <option value="admin">Admin</option>
            </select>

            <button className="btn btn-primary w-full" onClick={() => void sendInvite()} disabled={inviteSending} type="button">
              {inviteSending ? "Envoi..." : "Envoyer l’invitation"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
