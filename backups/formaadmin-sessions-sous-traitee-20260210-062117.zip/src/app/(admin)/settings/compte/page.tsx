'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase/browser'

type OrgType = 'personal' | 'business' | null

export default function AccountPage() {
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<string | null>(null)

  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')

  const [currentEmail, setCurrentEmail] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const [currentOrgType, setCurrentOrgType] = useState<OrgType>(null)
  const [currentOrgName, setCurrentOrgName] = useState('')

  const [memberships, setMemberships] = useState<any[]>([])
  const [wantedOrgId, setWantedOrgId] = useState<string | null>(null)

  const [creatingPersonal, setCreatingPersonal] = useState(false)

  const [deletePassword, setDeletePassword] = useState('')
  const [confirmDelete, setConfirmDelete] = useState(false)

  const refreshOrgs = async (userId: string) => {
    const { data: profile } = await supabase
      .from('profiles')
      .select('current_org_id')
      .eq('id', userId)
      .single()

    const { data: m, error: memError } = await supabase.rpc('get_my_memberships')
    if (memError) {
      setMessage(memError.message)
      return
    }

    const list = (m ?? []) as any[]
    setMemberships(list)

    const wanted = profile?.current_org_id ?? list?.[0]?.org_id ?? null
    setWantedOrgId(wanted)

    const current = list.find((x) => x?.org_id === wanted) ?? list?.[0] ?? null

    const orgTypeRaw = current?.org_type ?? current?.type ?? null
    const orgNameRaw = current?.org_name ?? current?.name ?? ''

    const normalized = String(orgTypeRaw ?? '').trim().toLowerCase()
    const normalizedType: OrgType =
      normalized === 'personal' || normalized === 'business' ? (normalized as OrgType) : null

    setCurrentOrgType(normalizedType)
    setCurrentOrgName(typeof orgNameRaw === 'string' ? orgNameRaw : '')
  }

  useEffect(() => {
    const load = async () => {
      const { data: auth } = await supabase.auth.getUser()
      const user = auth.user
      if (!user) return

      setCurrentEmail(user.email ?? '')
      setEmail(user.email ?? '')

      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('first_name,last_name')
        .eq('id', user.id)
        .single()

      if (profileError) {
        setMessage(profileError.message)
        setLoading(false)
        return
      }

      setFirstName(profile?.first_name ?? '')
      setLastName(profile?.last_name ?? '')

      await refreshOrgs(user.id)
      setLoading(false)
    }

    load()
  }, [])

  const createPersonalSpace = async () => {
    setCreatingPersonal(true)
    setMessage(null)

    const { data: auth } = await supabase.auth.getUser()
    const user = auth.user
    if (!user) return

    const { error } = await supabase.rpc('create_personal_org')
    if (error) {
      setMessage(error.message)
      setCreatingPersonal(false)
      return
    }

    // IMPORTANT: si ton RPC create_personal_org() ne set pas current_org_id,
    // alors va dans /settings/acces et clique "Ouvrir" sur l’espace perso.
    await refreshOrgs(user.id)

    setMessage('Espace formateur créé ✅ (si besoin: va dans Mes accès > Ouvrir)')
    setCreatingPersonal(false)
  }

  const save = async () => {
    setSaving(true)
    setMessage(null)

    const { data: auth } = await supabase.auth.getUser()
    const user = auth.user
    if (!user) return

    const { error: upProfileErr } = await supabase
      .from('profiles')
      .update({ first_name: firstName, last_name: lastName })
      .eq('id', user.id)

    if (upProfileErr) {
      setMessage(upProfileErr.message)
      setSaving(false)
      return
    }

    const payload: { email?: string; password?: string } = {}
    if (email !== currentEmail) payload.email = email
    if (password.length > 0) payload.password = password

    if (payload.email || payload.password) {
      const { error } = await supabase.auth.updateUser(payload)
      if (error) {
        setMessage(error.message)
        setSaving(false)
        return
      }
    }

    const refreshed = await supabase.auth.getUser()
    setCurrentEmail(refreshed.data.user?.email ?? '')
    setEmail(refreshed.data.user?.email ?? '')
    setPassword('')

    setMessage('Enregistré ✅')
    setSaving(false)
  }

  const deleteAccount = async () => {
    setMessage(null)

    const { error } = await supabase.auth.signInWithPassword({
      email: currentEmail,
      password: deletePassword,
    })

    if (error) {
      setMessage('Mot de passe incorrect')
      return
    }

    const { error: delErr } = await supabase.rpc('delete_my_account')
    if (delErr) {
      setMessage(delErr.message)
      return
    }

    await supabase.auth.signOut()
    window.location.href = '/'
  }

  const hasPersonal = memberships.some((m) => String(m?.org_type ?? '').trim().toLowerCase() === 'personal')

  return (
    <div className="space-y-10 max-w-2xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Mon compte</h1>
          <p className="text-sm text-gray-500">Informations personnelles et sécurité</p>
        </div>

        <button className="btn btn-primary" onClick={save} disabled={loading || saving}>
          {saving ? 'Enregistrement...' : 'Enregistrer'}
        </button>
      </div>

      {message && (
        <div className="rounded-xl border bg-gray-50 p-4 text-sm font-medium text-gray-700">
          {message}
        </div>
      )}

      <div className="card space-y-4">
        <h2 className="text-lg font-medium">Profil</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Prénom</label>
            <input className="input" value={firstName} onChange={(e) => setFirstName(e.target.value)} disabled={loading} />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Nom</label>
            <input className="input" value={lastName} onChange={(e) => setLastName(e.target.value)} disabled={loading} />
          </div>
        </div>

        <div className="rounded-xl border bg-gray-50 p-4 text-sm text-gray-700">
          <div className="font-medium">Statut</div>
          <div className="mt-1">
            {currentOrgType === 'personal'
              ? 'Formateur indépendant'
              : currentOrgType === 'business'
              ? 'Organisme de formation (OF)'
              : '—'}
            {currentOrgName ? ` — ${currentOrgName}` : ''}
          </div>
          <div className="mt-2 text-xs text-gray-500">
            current_org_id: {String(wantedOrgId)}
          </div>
        </div>

        <div className="flex gap-3">
          <button
            className="btn btn-secondary"
            onClick={createPersonalSpace}
            disabled={creatingPersonal || hasPersonal}
          >
            {hasPersonal ? 'Espace formateur déjà existant' : creatingPersonal ? 'Création...' : 'Créer mon espace formateur'}
          </button>

          <button className="btn btn-primary" onClick={() => (window.location.href = '/settings/acces')}>
            Aller à Mes accès
          </button>
        </div>
      </div>

      <div className="card space-y-4">
        <h2 className="text-lg font-medium">Identité de connexion</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Adresse email</label>
            <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} disabled={loading} />
            <p className="text-xs text-gray-500">Email actuel : {currentEmail || '-'}</p>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Nouveau mot de passe</label>
            <input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} disabled={loading} />
            <p className="text-xs text-gray-500">Laisser vide pour ne pas changer</p>
          </div>
        </div>
      </div>

      <div className="card space-y-4 border-red-200">
        <h2 className="text-lg font-medium text-red-600">Supprimer mon compte</h2>

        <p className="text-sm text-gray-600">
          Cette action est définitive. Vos données personnelles seront supprimées.
        </p>

        <input
          className="input"
          type="password"
          placeholder="Mot de passe pour confirmer"
          value={deletePassword}
          onChange={(e) => setDeletePassword(e.target.value)}
        />

        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={confirmDelete} onChange={(e) => setConfirmDelete(e.target.checked)} />
          Je comprends que cette action est irréversible
        </label>

        <button className="btn btn-danger" disabled={!confirmDelete || !deletePassword} onClick={deleteAccount}>
          Supprimer définitivement
        </button>
      </div>
    </div>
  )
}
